from customtkinter import *
import pandas as pd
from datetime import datetime
import serial
import time
import re
from datetime import datetime

serial_port = "COM13"
ser = serial.Serial(serial_port,115200, timeout=1)

temp_value_Label = None
scl1 = None  
threshold_value_label = None 
switch_ON = None

username = None  

def validate_login(user_name,password):
    if user_name=="ravi" and password == str(1234) :
        return True
    else:
        return False

def login():
    global username
    login_window = CTk()
    login_window.title("Login")

    username_label = CTkLabel(login_window, text="Username:")
    username_label.grid(row=0, column=0, padx=10, pady=10)

    username_entry = CTkEntry(login_window)
    username_entry.grid(row=0, column=1, padx=10, pady=10)

    password_label = CTkLabel(login_window, text="Password:")
    password_label.grid(row=1, column=0, padx=10, pady=10)

    password_entry = CTkEntry(login_window, show="*")
    password_entry.grid(row=1, column=1, padx=10, pady=10)

    login_button = CTkButton(login_window, text="Login", command=lambda: on_login(username_entry.get(), password_entry.get(), login_window))
    login_button.grid(row=2, columnspan=2, pady=10)

    login_window.mainloop()

def on_login(username, password, login_window):
    
    if validate_login(username, password):
        print(f"Welcome, {username}!")
        login_window.destroy()
       
    else:
        print("Invalid login. Please try again.")

def read_serial():
    global temp_value_Label,tempvalue
    tempvalue=0
    
    try:
        
        data = ser.readline().decode('utf-8').strip()

        if data:
            
            match = re.search(r'Temperature: (\d+\.\d+)', data)
            if match:
                tempvalue = float(match.group(1))
                current_tempvalue(tempvalue)
                

        window.after(5000, read_serial)
        if temp_value_Label is not None:  
            value = round(tempvalue, 2)
            temp_value_Label.configure(text=f"Current temp Value: {value}")

    except serial.SerialException as e:
        print(f"Error reading from serial port: {e}")
            

def Auto_Mode():
    global scl1, threshold_value_label
    Auto_mode_Value = Auto_mode.get()

    if Auto_mode_Value == 1:
        Auto.configure(text="Auto mode")
        frame1.grid(row=0, column=1, padx=20, pady=20)
        Label1 = CTkLabel(frame1, text="Scale Threshold value")
        Label1.grid(row=1, column=1)

        scl1 = CTkSlider(frame1, from_=0, to=100, command=currentvalue)
        scl1.grid(row=1, column=2, pady=20)
        scl1.set(0)

        threshold_value_label = CTkLabel(frame1, text="Current Threshold Value: 0")
        threshold_value_label.grid(row=2, column=1)

    else:
        for widget in frame1.winfo_children():
            widget.destroy()
        frame1.grid_forget()
        Auto.configure(text="Set mode")

def Manual_Mode():
    global switch_ON  
    manual_mode_Value = Manual_mode.get()
    if manual_mode_Value == 1:
        frame4.grid(row=1, column=0, padx=20, pady=20)
        Auto.configure(text="Manual mode")
        print("Manual Mode ON")

        switch_ON = CTkSwitch(frame4, text="Fan_ON", command=lambda: Fan_ON(switch_ON))
        switch_ON.grid(column=1, row=3)

    else:
        for widget in frame4.winfo_children():
            widget.destroy()
        frame4.grid_forget()
        Auto.configure(text="Set mode")
        
def Fan_ON(switch_ON):
    if switch_ON.get() == 1:
        print("Fan=ON")
        ser.write(b"A")
    if switch_ON.get() == 0:
        print("Fan=OFF")
        ser.write(b"B")
    Manual_update_log(tempvalue)

def currentvalue(value):

    global scl1, threshold_value_label
    value = round(value, 2)
    threshold_value_label.configure(text=f"Current Threshold Value: {value}")
    Auto_update_log(value,tempvalue)

def current_tempvalue(value):
    global tempvalue, temp_value_Label, scl1
    value1 = round(value, 2)
    temp_value_Label.configure(text=f"Current temp Value: {value1} degrees ")
    
    if Manual_mode.get() == 1:
        Manual_update_log(value1)
    if Auto_mode.get() == 1:
        Auto_update_log(round(scl1.get(),2),value)
    

def Auto_update_log(value1,value2):

    timestamp = datetime.now()
    if value1>0:
        threshold_value = round(value1, 2)
        temp_value = round(value2, 2)
        print("tem_Value"+str(temp_value))
       
        if threshold_value < temp_value:
            print("Fan-ON")
            fan_status = "Fan-ON"
            ser.write(b"A")
            
        else :
            fan_status="Fan-OFF"
            print("Fan-OFF")
            ser.write(b"B")
        
        gui_mode = "Auto" if Auto_mode.get() == 1 else "none"

    else:
        threshold_value = 0
        fan_status="Fan-OFF"
        gui_mode = "Auto"
        

    global log_data
    new_data = pd.DataFrame({
        'Timestamp': [timestamp],
        'ThresholdValue': [threshold_value],
        'TempValue': [value2],
        'FanStatus': [fan_status],
        'GUIMode': [gui_mode]
    })
    log_data = pd.concat([log_data, new_data], ignore_index=True)

def Manual_update_log(value):
    timestamp = datetime.now()
    fan_status = "Fan-ON" if switch_ON.get() == 1 else "Fan-OFF"
    gui_mode = "manual" if Manual_mode.get() == 1 else "none"
    tempvalue=value
    global log_data
    new_data = pd.DataFrame({
        'Timestamp': [timestamp],
        'ThresholdValue': ["None"],
        'TempValue': [tempvalue],
        'FanStatus': [fan_status],
        'GUIMode': [gui_mode]
    })
    log_data = pd.concat([log_data, new_data], ignore_index=True)

login()
window = CTk()
window.title("SCADA SYSTEM")
window.geometry('700x300')

frame1 = CTkFrame(window, width=100)
frame2 = CTkFrame(window, width=100)
frame2.grid(row=0, column=0, padx=20, pady=20)
frame3 = CTkFrame(window, width=100)
frame3.grid(row=1, column=1, padx=20, pady=20)
frame4 = CTkFrame(window, width=100)


log_data = pd.DataFrame(columns=['Timestamp', 'ThresholdValue', 'TempValue', 'FanStatus', 'GUIMode'])

Auto = CTkLabel(frame2, text="Set mode")
Auto.grid(row=1, column=2)

temp_value_Label = CTkLabel(frame2, text="Current temp Value: 0")
temp_value_Label.grid(row=3, column=1)
                      
button_STOP = CTkButton(frame3, text="STOP", command=window.quit)
button_STOP.grid(column=2, row=6)

button_EXIT = CTkButton(frame3, text="EXIT", command=window.destroy)
button_EXIT.grid(column=3, row=6)

Manual_mode = CTkSwitch(frame2, text="Manual_Mode", command=Manual_Mode)
Manual_mode.grid(row=1, column=1)

Auto_mode = CTkSwitch(frame2, text="Auto_Mode", command=Auto_Mode)
Auto_mode.grid(row=2, column=1)

read_serial()
window.mainloop()


log_filename = '190524T(1)_log.xlsx'
log_data.to_excel(log_filename, index=False)

print(f"Data logged to {log_filename}")
